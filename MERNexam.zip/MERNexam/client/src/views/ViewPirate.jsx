import React, { useEffect, useState } from 'react';
import axios from "axios"
import { Link, useParams } from 'react-router-dom';

const ViewPirate = () => {
    const [pirate, setPirate] = useState()
    const { id } = useParams()

    useEffect(() => {
        axios.get(`http://localhost:8000/api/pirate/` + id)
            .then(res => setPirate(res.data))
            .catch(err => console.log(err))
    }, [])

    return (
        <div>
            {
            pirate ?
            <div className=''>
                <div>
                    <header className='d-flex p-3 justify-content-between align-items-center bg-secondary'>
                        <h1>{pirate.name}</h1>
                        <Link type="button" to='/'><button className='btn btn-primary'>View Crew</button></Link>
                    </header>
                </div>
                <div className='d-flex justify-content-around bg-success p-2'>
                    <div>
                        <img src={pirate.image} alt=""/>
                        <h1>"{pirate.phrase}"</h1>
                    </div>
                    <div className='d-flex-column justify-content-center'>
                        <h2>About</h2>
                        <h4>Position: {pirate.position}</h4>
                        <h4>Treasures: {pirate.treasure}</h4>
                        <h4>Pegleg: {pirate.pegleg ? "Yes" : "No"} </h4>
                        <h4>Eyepatch: {pirate.eyepatch ? "Yes" : "No"} </h4>
                        <h4>Hookhand: {pirate.hookhand ? "Yes" : "No"} </h4>
                    </div>
                </div>

            </div>
            
            :
            <h2>No Pirate, He Ded</h2>
            }
        </div >

    )
}

export default ViewPirate
