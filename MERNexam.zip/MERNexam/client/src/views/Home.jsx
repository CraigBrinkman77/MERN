import React, { useEffect, useState } from 'react';
import axios from "axios"
import { Link } from 'react-router-dom';
import DeleteButton from '../components/DeleteButton';

const Home = () => {
    const [pirates, setPirates] = useState([])
    const [refresh, setRefresh] = useState(true)

    useEffect(() => {
        axios.get(`http://localhost:8000/api/pirates`)
            .then(res => {
                console.log(res.data.sort({name:1}))
                // const alapha = _.sortBy(res.data, "name")
                // console.log(alapha)
                setPirates(res.data)
            })
            .catch(err => console.log(err))
    }, [refresh])

    const reloadList = () =>{
        setRefresh(!refresh)
    }

    return (
        <div>
            <header className='d-flex p-3 justify-content-between align-items-center bg-secondary'>
                <h1>Pirate Crew</h1>
                <Link type="button" to='/pirate/create'><button className='btn btn-primary'>Create Pirate</button></Link>
            </header>
            {
            pirates?
            pirates.map((pirate, i) =>{
                return(
            <div key={i} className='d-flex justify-content-between p-4'>
                <img src={pirate.image} alt=""/>
                <div className='d-flex-coulmn justify-content-center'>
                    <h2>{pirate.name}</h2>
                    <div>
                    <Link type="button" to={`/pirate/view/${pirate._id}`} ><button className='btn btn-primary m-1'>View Pirate</button></Link>
                    <DeleteButton id={pirate._id} deleteHandler={reloadList}></DeleteButton>
                    </div>
                </div>
            </div>
            )})
            :
            <h2>No Pirates, They Ded</h2>
            }
        </div>
    )
}

export default Home
