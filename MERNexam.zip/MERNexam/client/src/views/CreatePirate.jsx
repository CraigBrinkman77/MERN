import React from 'react'
import CreateForm from '../components/CreateForm'
import { Link } from 'react-router-dom'

const CreatePirate = () => {

    return (
        <div>
            <header className='d-flex p-3 justify-content-between align-items-center bg-secondary'>
                <h1>Create Crew Member</h1>
                <Link type="button" to='/'><button className='btn btn-primary'>View Crew</button></Link>
            </header>
            <CreateForm />
        </div>
    )
}

export default CreatePirate
