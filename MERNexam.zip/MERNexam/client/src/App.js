import {BrowserRouter, Switch, Route} from "react-router-dom"
import CreatePirate from "./views/CreatePirate";
import Home from "./views/Home";
import ViewPirate from "./views/ViewPirate";

function App() {
  return (
    <div className="container">
      <BrowserRouter>
        <Switch>
          <Route exact path = "/">
            <Home />
          </Route>
          <Route exact path = "/pirate/view/:id">
            <ViewPirate />
          </Route>
          <Route exact path = "/pirate/create">
            <CreatePirate />
          </Route>
        </Switch>
      </BrowserRouter>
      
    </div>
  );
}

export default App;
