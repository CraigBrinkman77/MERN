import React, { useState } from 'react';
import axios from "axios"
import { useHistory } from 'react-router-dom';

const CreateForm = () => {

    const [name, setName] = useState("")
    const [image, setImage] = useState("")
    const [phrase, setPhrase] = useState("")
    const [position, setPosition] = useState("captain")
    const [treasure, setTreasure] = useState(0)
    const [eyepatch, setEyepatch] = useState(true)
    const [pegleg, setPegleg] = useState(true)
    const [hookhand, setHookhand] = useState(true)

    const history = useHistory()

    const [errArray, setErrArray] = useState([])

    const submitHandler = (e) => {
        e.preventDefault()
        axios.post(`http://localhost:8000/api/pirate/create`, { name, image, phrase, position, treasure, eyepatch, hookhand, pegleg })
            .then(res => {
                history.push("/")
            })
            .catch(err => {
                const errResponse = err.response.data.errors
                let tempArr = [];
                for (const key of Object.keys(errResponse)) {
                    tempArr.push(`${errResponse[key].message}`)}
                setErrArray(tempArr)
            })
        }

        return (
            <div>
                <form onSubmit={submitHandler}>
                    <div>
                        <label> Name</label>
                        <input type="text" name="name" value={name} onChange={e => setName(e.target.value)} />
                    </div>
                    <div>
                        <label> Phrase</label>
                        <input type="textarea" name="phrase" value={phrase} onChange={e => setPhrase(e.target.value)} />
                    </div>
                    <div>
                        <label> Image Url: </label>
                        <input type="text" name="image" value={image} onChange={e => setImage(e.target.value)} />
                    </div>
                    <div>
                        <label> Position</label>
                        <select name="position" onChange={e => setPosition(e.target.value)}>
                            <option value="captain">Captain</option>
                            <option value="crew">Crew</option>
                            <option value="janitor">Janitor</option>
                        </select>
                    </div>
                    <div>
                        <label> Treasure Chests</label>
                        <input type="number" name="treasure" value={treasure} onChange={e => setTreasure(e.target.value)} />
                    </div>
                    <div>
                        <label> Pegleg:</label>
                        <input type="checkbox" name="pegleg" checked={pegleg} onChange={e => setPegleg(!pegleg)} />
                    </div>
                    <div>
                        <label> Hookhand:</label>
                        <input type="checkbox" name="hookhand" checked={hookhand} onChange={e => setHookhand(!hookhand)} />
                    </div>
                    <div>
                        <label> Eyepatch:</label>
                        <input type="checkbox" name="eyepatch" checked={eyepatch} onChange={e => setEyepatch(!eyepatch)} />
                    </div>

                    <button className='btn btn-success'> Add Pirate</button>
                </form>
                {
                    errArray&&
                    errArray.map((err, i) => (
                        <p key={i}>{err}</p>
                    ))
                }
            </div>
        );
}
export default CreateForm
