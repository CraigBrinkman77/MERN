const pirateController = require('../controllers/pirate.controller');

module.exports = (app) => {
    app.post('/api/pirate/create', pirateController.createPirate)
    app.get('/api/pirates', pirateController.getAllPirates)
    app.get('/api/pirate/:id', pirateController.getPirate)
    app.put('/api/pirate/update/:id', pirateController.updatePirate)
    app.delete('/api/pirate/delete/:id', pirateController.deletePirate)
}