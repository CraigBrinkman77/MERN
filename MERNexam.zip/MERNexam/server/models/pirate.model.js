const mongoose = require('mongoose');

const PirateSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Name is required!"],
        minlength: [2, "Name must be at least 2 characters!"]
    },
    image: {
        type: String,
        required: [true, "Image is required!"],
        minlength: [10, "Image must be url"]
    },
    phrase: {
        type: String,
        required: [true, "Phrase is required!"],
        minlength: [2, "Pharse must be at least 2 characters!"]
    },
    treasure: {
        type: Number,
        required: [true, "Treasure is required!"],
        min: [0, "Treasure must be greater than 0!"]
    },
    position: {
        type: String,
        required: [true, "Position is required!"]
    },
    pegleg: {
        type: Boolean,
        required: [true, "Required"]
    },
    eyepatch: {
        type: Boolean,
        required: [true, "Required"]
    },
    hookhand: {
        type: Boolean,
        required: [true, "Required"]
    }
}, {timestamps: true});

module.exports.Pirate = mongoose.model('Pirate', PirateSchema);